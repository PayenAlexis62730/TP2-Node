const { insertOne } = require ("./crud")

async function createUser(req , res , next){
    const value = req.body ;
    console.log(value);
    const collection = "users";
    const result = await insertOne(collection , value);
    return res.status(200).send(result);
}


module.exports = {
    createUser,
};