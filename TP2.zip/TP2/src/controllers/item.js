const { insertOne } = require ("./crud")

async function addItem(req , res , next){
    const value = req.body ;
    console.log(value);
    const collection = "item";
    const result = await insertOne(collection , value);
    return res.status(200).send(result);
}

async function updateItemStatusInWatchlist(req, res, next) {
    const { watchlistId, itemId, status } = req.body;
    const watchlistCollection = "watchlists";

    // Mettre à jour le statut de l'élément dans la watchlist
    const watchlistUpdate = await updateOne(
        watchlistCollection,
        { _id: watchlistId, "items._id": itemId },
        { $set: { "items.$.status": status } }
    );

    return res.status(200).send(watchlistUpdate);
}

async function getItemsFromRegistry(req, res, next) {
    const { filter } = req.query;
    const itemCollection = "items";

    // Récupérer les éléments du registre avec un filtrage
    const items = await find(itemCollection, filter ? JSON.parse(filter) : {});

    return res.status(200).send(items);
}


module.exports = {
    addItem,
    updateItemStatusInWatchlist,
    getItemsFromRegistry
};