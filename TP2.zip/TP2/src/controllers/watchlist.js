const { insertOne } = require ("./crud")

async function createWatchlist(req, res, next) {
    const value = req.body;
    console.log(value);
    const collection = "watchlists";
    const result = await insertOne(collection, value);
    return res.status(200).send(result);
}

async function addItemToWatchlist(req, res, next) {
    const { watchlistId, itemId } = req.body;
    const watchlistCollection = "watchlists";
    const itemCollection = "item";
    
    // Vérifier si l'élément existe 
    const itemExists = await find(itemCollection, { _id: itemId });
    if (!itemExists) {
        return res.status(400).send("L'élément spécifié n'existe pas.");
    }

    // Ajouter l'élément à la watchlist
    const watchlistUpdate = await updateOne(
        watchlistCollection,
        { _id: watchlistId },
        { $push: { items: itemId } }
    );

    return res.status(200).send(watchlistUpdate);
}


module.exports = {
    createWatchlist,
    addItemToWatchlist,
};