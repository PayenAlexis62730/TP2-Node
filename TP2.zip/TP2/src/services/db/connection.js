const { MongoClient } = require('mongodb');
const conf = require("./conf.json")

const url = conf.databaseUrl || 'mongodb://localhost:27017'; // Utilisez une valeur par défaut si la chaîne de connexion est vide
const dbName = conf.databaseName;

// Create a new MongoClient
const client = new MongoClient(url);

async function connectTodB() {
    try {
        console.log('Trying to access the db...');
        // Connect the client to the server (optional starting in v4.7)
        await client.connect();

        // Establish and verify connection
        await client.db('admin').command({ ping: 1 });
        console.log('Connected successfully to server');
    } catch (e) {
        // Ensures that the client will close when you finish/error
        console.log(JSON.stringify(err));
        await client.close();
        throw e;
    }
}

function getCollection(collectionName) {
    return client.db(dbName).collection(collectionName);
}

module.exports = {
    connectTodB,
    getCollection,
};