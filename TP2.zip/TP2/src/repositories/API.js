const axios = require('axios');

const URL_OMDB_API = 'http://www.omdbapi.com';
const CLE_API_OMDB = 'd2e988f8'; 

// Fonction pour rechercher un élément (film ou série) sur omdbapi
async function rechercherElement(query) {
  try {
    const reponse = await axios.get(`${URL_OMDB_API}/?apikey=${CLE_API_OMDB}&s=${query}`);
    return reponse.data;
  } catch (erreur) {
    console.error('Erreur lors de la recherche d\'élément sur omdbapi :', erreur.message);
    throw erreur;
  }
}

// Fonction pour obtenir les détails d'un élément spécifique par son ID sur omdbapi
async function obtenirDetailsElement(itemId) {
  try {
    const reponse = await axios.get(`${URL_OMDB_API}/?apikey=${CLE_API_OMDB}&i=${itemId}`);
    return reponse.data;
  } catch (erreur) {
    console.error('Erreur lors de l\'obtention des détails de l\'élément depuis omdbapi :', erreur.message);
    throw erreur;
  }
}

module.exports = {
  rechercherElement,
  obtenirDetailsElement,
};
